//是否正在下载
var isDownLoading = false;
//反馈类型
var suggestionTypeObj = new Object();
suggestionTypeObj["01"] = "意见建议";
suggestionTypeObj["02"] = "问题反馈";
//app应用信息
var appObj = new Object();
//获取app信息成功
function getAppInfosSuccess(data)
{
	for (var i=0; i<data.length; i++)
	{
		appObj[data[i].appId] = data[i].appName;
	}
	querySuggestionDetail();
}

//查询意见反馈详细信息
function querySuggestionDetail()
{
	var requestParam = getRequest();
	var suggestionId = requestParam.suggestionId;
	var param = {
			suggestionId: suggestionId
	};
	stereo.system.dialog({
		"model" : "show",
		"info" : "请稍候..."
	});
	stereo.system.getSuggestionDetail(param, getSuggestionDetailSuccess, fail);
}

//获取意见反馈详细信息成功
function getSuggestionDetailSuccess(data)
{
	stereo.system.dialog({
		"model" : "close"
	});
	$("#suggestionType").html(suggestionTypeObj[data.suggestionType]);
	$("#appName").html(appObj[data.appId]);
	$("#submitTime").html(new Date(data.submitTime).format("yyyy-MM-dd"));
	$("#content").val(data.content);
	//状态01：未回复，02：已回复
//	var replyContent = '<div class="titleDiv">回复结果</div>';
	var replyContent = '';
	if ("02" == data.status)
	{
//		replyContent += '<div class="detailRowDiv" style="border-top: 1px solid #C7C7CC;">' +
//							'<div>回复人</div>' +
//							'<div id="replyUserName">' + data.replyUserName + '</div>' +
//						'</div>' +
//						'<div class="detailRowDiv">' +
//							'<div>回复时间</div>' +
//							'<div id="replyTime">' + new Date(data.replyTime).format("yyyy-MM-dd") + '</div>' +
//						'</div>' +
//						'<div style="display:-webkit-box;-webkit-box-orient:horizontal;border-bottom: 1px solid #C7C7CC;' +
//							'padding:0 10px 0 10px;background:#FFFFFF;">' +
//							'<div style="width:160px;line-height:50px;text-align:left;">回复内容</div>' +
//							'<div style="display:-webkit-box;-webkit-box-flex:1;">' +
//								'<textarea id="replyContent" maxlength="300" class="mult-text-input" disabled="disabled" ' +
//									'style="background:#FFFFFF;text-align:right;padding:10px 0 10px 0;">' +
//								'</textarea>' +
//							'</div>' +
//						'</div>';
		replyContent += '<div class="titleDiv">系统回复</div>';
		replyContent += '<div style="border-top: 1px solid #C7C7CC;border-bottom: 1px solid #C7C7CC;' +
								'padding:10px;background:#FFFFFF;">' +
							'<div style="width:100%;min-height:60px;">' + data.replyContent + '</div>' +
							'<div style="width:100%;text-align:right;">' + new Date(data.replyTime).format("yyyy-MM-dd") + '</div>' +
						'</div>';
	}
	else
	{
//		replyContent += '<div class="detailRowDiv" style="border-top: 1px solid #C7C7CC;">' +
//							'<div style="width:200px;">暂未回复，请耐心等待。</div>' +
//						'</div>';
		replyContent += '<div style="text-align:center;"><img src="img/plus.png" style="vertical-align:middle;" /> 该问题暂未回复，请耐心等待。</div>';
	}
	$("#replyDiv").html(replyContent);
//	$("#replyContent").val(data.replyContent);
	var mediaIds = data.mediaIds;
	if (null != mediaIds && undefined != mediaIds && 0 != mediaIds.length)
	{
		isDownLoading = true;
		//下载证件照
		stereo.file.download({
			mediaID: mediaIds
		}, downloadSuccess, fail);
	}
	else
	{
		$(".loading").hide();
		$("#imgs").parent().css("padding-left", "10px");
		$("#imgs").show();
		$("#imgs").html("未上传截图");
//		$("#imgsDiv").hide();
	}
}

//下载图片成功
function downloadSuccess(data)
{
	isDownLoading = false;
	$(".loading").hide();
	$("#imgs").show();
	var datas = data.split(",");
	var imgContent = '';
	for (var i=0; i<datas.length; i++)
	{
		imgContent += '<img class="singleImg" onclick="previewImg(this)" src="' + datas[i] + '" />';
	}
	$("#imgs").html(imgContent);
	initCross();
}

//请求失败回调
function fail(data)
{
	alert(data);
}

//初始化图片及新增按钮
function initCross()
{
	var crossWidth = $("#imgs").width()/5-5-2;
	var crossLineWidth = $(".crossDiv div").eq(0).width();
	$(".crossDiv").css("width", crossWidth);
	$(".crossDiv div").eq(0).css("left", (crossWidth - crossLineWidth)/2);
	$(".crossDiv div").eq(1).css("left", (crossWidth - crossLineWidth)/2);
	$(".singleImg").eq(0).css("width", crossWidth);
	$(".singleImg").eq(1).css("width", crossWidth);
	$(".singleImg").eq(2).css("width", crossWidth);
	$(".singleImg").eq(3).css("width", crossWidth);
	$(".singleImg").eq(4).css("width", crossWidth);
}

//预览图片
function previewImg(target)
{
	var imgs = $("#imgs >img");
	var imgsArray = [];
	for (var i=0; i<imgs.length; i++)
	{
		imgsArray.push($(imgs[i]).attr("src"));
	}
	var paramJson = {
			images: imgsArray,
			viewModel: "slider",
			src: $(target).attr("src")
		};
	//预览图片
	stereo.camera.imagePreview(paramJson);
}

function hback()
{
	//如果正在下载证件照
	if (isDownLoading)
	{
		//取消下载证件照
		stereo.file.cancelDownload({}, null, null);
	}
	//调用平台的返回方法
	stereo.system.goback();
}

function getRequest() 
{ 
	var url = location.search; //获取url中"?"符后的字串
	var theRequest = new Object();
	if (url.indexOf("?") != -1)
	{
		var str = url.substr(1);
		strs = str.split("&");
		for(var i = 0; i < strs.length; i ++)
		{
			theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
		}
	}
	return theRequest;
}

Date.prototype.format = function (fmt) { //author: meizz 
    var o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "h+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
};