//当前页码
var pageNo = 1;
//每页记录数目
var pageSize = 15;
//总页数
var totalPage = 1;
//app应用信息
var appObj = new Object();

//获取app信息成功
function getAppInfosSuccess(data)
{
	for (var i=0; i<data.length; i++)
	{
		appObj[data[i].appId] = data[i].appName;
	}
	querySuggestions();
}

//查询所有 意见反馈
function querySuggestions()
{
	stereo.system.dialog({
		"model" : "show",
		"info" : "请稍候..."
	});
	$("#pullUp").show();
	var param = {
			pageNo: pageNo,
			pageSize: pageSize
	};
	stereo.system.getSuggestions(param, getSuggestionsSuccess, fail);
}

//查询所有 意见反馈成功
function getSuggestionsSuccess(data)
{
	stereo.system.dialog({
		"model" : "close"
	});
	//设置总页数
	totalPage = data.totalPage;
	//如果没有 意见反馈 记录，跳转至新增页面
	if (0 == totalPage)
	{
		window.location.href = "addFeedback.html";
		return;
	}
	//当前页记录
	var suggestions = data.results;
	if (1 == pageNo)
	{
		//清空意见反馈列表
		$("#suggestionsUl").html('');
	}
	//如果已经是最后一页，隐藏上拉加载更多
	if (pageNo == data.totalPage)
	{
		pullScroll.refresh();
    	$("#pullUp").hide();
    	hasLoadedAll=true;
	}
	//已展示的用户列表
	var suggestionsUlContent = $("#suggestionsUl").html();
	for (var i=0; i<suggestions.length; i++)
	{
		// 反馈类型01:意见建议，02：问题反馈
		var imgSrc = "";
		if ("01" == suggestions[i].SUGGESTION_TYPE)
		{
			imgSrc = "img/user.png";
		}
		else
		{
			imgSrc = "img/shop.png";
		}
		// 状态01：未回复，02：已回复
		var statusAndDate = "";
		var date = "";
		if ("01" == suggestions[i].STATUS)
		{
			date = new Date(suggestions[i].SUBMIT_TIME).format("yyyy-MM-dd");
			statusAndDate = '<div style="color:#BBBBBB;width:100%;font-size:16px;">' + date + '&nbsp;&nbsp;</div>';
		}
		else
		{
			date = new Date(suggestions[i].REPLY_TIME).format("yyyy-MM-dd");
			statusAndDate = '<div style="color:#38B69A;width:50%;font-size:16px;">已回复</div><div style="color:#BBBBBB;width:50%;font-size:16px;">' + date + '&nbsp;&nbsp;</div>';
		}
		suggestionsUlContent += '<li><div class="rowDiv">' +
				'<input type="hidden" value="' + suggestions[i].SUGGESTION_ID + '"/>' +
				'<div style="width:20%;" class="div_img">' +
					'<img class="img" style="width:64px;height:64px;" src="' + imgSrc + '">' +
				'</div>' +
				'<div style="width:80%;height:100%;">' +
					'<div style="width:100%;height:50%;display:-webkit-box;-webkit-box-orient:horizontal;">' +
						'<div style="width:40%;line-height:55px;color:#333333;font-size:20px;">' + appObj[suggestions[i].APP_ID] + '</div>' +
						'<div style="width:60%;line-height:55px;display:-webkit-box;-webkit-box-orient:horizontal;text-align:right;">' + statusAndDate + '</div>' +
					'</div>' +
					'<div style="width:100%;height:50%;display:-webkit-box;-webkit-box-orient:horizontal;">' +
						'<div style="line-height:40px;width:90%;color:#BBBBBB;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;display:block;">' + suggestions[i].CONTENT + '</div>' +
					'</div>' +
				'</div>' +
			'</div><li>';
	}
	$("#suggestionsUl").html(suggestionsUlContent);
	//刷新列表
    pullScroll.refresh();
    $("#suggestionsUl .rowDiv").click(function(){
    	var suggestionId = $(this).children().eq(0).val();
    	//跳转至用户详细信息页面
		window.location.href = "detail.html?suggestionId="+suggestionId;
    });
}

//请求失败回调
function fail(data)
{
	alert(data);
}

var hasLoadedAll = false;
var pullScroll,
pullDownEl, pullDownOffset,
pullUpEl, pullUpOffset,
generatedCount = 0;

function pullDownAction() {
	pageNo=1;
	hasLoadedAll=false;
	querySuggestions();
}

function pullUpAction() {
	pageNo++;
	querySuggestions();
}

function loadedPull() {
	pullDownEl = document.getElementById('pullDown');
	pullDownOffset = pullDownEl.offsetHeight;
	pullUpEl = document.getElementById('pullUp');
	pullUpOffset = pullUpEl.offsetHeight;
	
	pullScroll = new iScroll('wrapper_pull', {
		scrollbarClass: 'myScrollbar',
		useTransition: false,
		topOffset: pullDownOffset,
		hScroll:false,
		onRefresh: function () {
			if (pullDownEl.className.match('loading')) {
				pullDownEl.className = '';
				pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉刷新...';
			} else if (pullUpEl.className.match('loading')) {
				pullUpEl.className = '';
				pullUpEl.querySelector('.pullUpLabel').innerHTML = '上拉加载更多...';
			}
		},
		onScrollMove: function () {
			if (this.y > 5 && !pullDownEl.className.match('flip')) {
				pullDownEl.className = 'flip';
				pullDownEl.querySelector('.pullDownLabel').innerHTML = '松开即可刷新...';
				this.minScrollY = 0;
			} else if (this.y < 5 && pullDownEl.className.match('flip')) {
				pullDownEl.className = '';
				pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉刷新...';
				this.minScrollY = -pullDownOffset;
			} else if (this.y < (this.maxScrollY - 5) && !pullUpEl.className.match('flip') && !hasLoadedAll) {
				pullUpEl.className = 'flip';
				pullUpEl.querySelector('.pullUpLabel').innerHTML = '松开即可加载更多...';
				this.maxScrollY = this.maxScrollY;
			} else if (this.y > (this.maxScrollY + 5) && pullUpEl.className.match('flip') && !hasLoadedAll) {
				pullUpEl.className = '';
				pullUpEl.querySelector('.pullUpLabel').innerHTML = '上拉加载更多...';
				this.maxScrollY = pullUpOffset;
			}
		},
		onScrollEnd: function () {
			if (pullDownEl.className.match('flip')) {
				pullDownEl.className = 'loading';
				pullDownEl.querySelector('.pullDownLabel').innerHTML = '正在加载...';				
				pullDownAction();	// Execute custom function (ajax call?)
			} else if (pullUpEl.className.match('flip') && !hasLoadedAll) {
				pullUpEl.className = 'loading';
				pullUpEl.querySelector('.pullUpLabel').innerHTML = '正在加载...';				
				pullUpAction();	// Execute custom function (ajax call?)
			}
		}
	});
	
	setTimeout(function () { document.getElementById('wrapper_pull').style.left = '0'; }, 800);
}

document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);
document.addEventListener('DOMContentLoaded', loadedPull, false);

Date.prototype.format = function (fmt) { //author: meizz 
    var o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "h+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
};