function init()
{
	//初始化图片及新增按钮
	initCross();
	//获取app信息
	stereo.system.getAppInfos([], getAppInfosSuccess, null);
}

//初始化图片及新增按钮
function initCross()
{
	var crossWidth = $("#imgs").width()/5-5-2;
	var crossLineWidth = $(".crossDiv div").eq(0).width();
	$(".crossDiv").css("width", crossWidth);
	$(".crossDiv div").eq(0).css("left", (crossWidth - crossLineWidth)/2);
	$(".crossDiv div").eq(1).css("left", (crossWidth - crossLineWidth)/2);
	$(".singleImg").eq(0).css("width", crossWidth);
	$(".singleImg").eq(1).css("width", crossWidth);
	$(".singleImg").eq(2).css("width", crossWidth);
	$(".singleImg").eq(3).css("width", crossWidth);
	$(".singleImg").eq(4).css("width", crossWidth);
}

//添加图片
function addImgs()
{
	var imgs = $("#imgs >img");
	var paramJson = {
		chooseModel: "picture",
		imageCount : 5-imgs.length
	};
	//调用app原生应用，弹出pop菜单，让用户选择拍照，还是从相册获取
	stereo.camera.chooseImage(paramJson, cameraSuccess, fail);
}

//图片选择成功回调
function cameraSuccess(data){
	var imgHtml = '';
	if(data.photos == 0)
	{
		stereo.system.info({
			title: '提示',
			info: '请选择图片',
			timeout: '2000'
		});
		return;
	}
	for (var i=0; i<data.photofile.length; i++)
	{
		imgHtml += '<img class="singleImg" onclick="previewImg(this)" src="' + data.photofile[i] + '" />';
	}
	$(imgHtml).insertBefore('.crossDiv');
	var imgs = $("#imgs >img");
	if (5 == imgs.length)
	{
		$(".crossDiv").hide();
	}
	//重新初始化图片及新增按钮
	initCross();
}

//预览图片
function previewImg(target)
{
	var imgs = $("#imgs >img");
	var imgsArray = [];
	for (var i=0; i<imgs.length; i++)
	{
		imgsArray.push($(imgs[i]).attr("src"));
	}
	var paramJson = {
			images: imgsArray,
			viewModel: "slider",
			src: $(target).attr("src")
		};
	//预览图片
	stereo.camera.imagePreview(paramJson);
}

//提交意见反馈
function submit()
{
	if (isNull($("#context").val()))
	{
		stereo.system.info({
			title: '提示',
			info:'请填写"问题和意见"',
			timeout: '2000'
		});
		return false;
	}
	//图片
	var imgs = $("#imgs >img");
	var imgsArray = [];
	for (var i=0; i<imgs.length; i++)
	{
		imgsArray.push($(imgs[i]).attr("src"));
	}
	
	if (0 == imgsArray.length)
	{
		uploadSuccess(null);
	}
	else
	{
		//上传图片
		var fileParam = {
				fileType: "JPG",
				files: imgsArray
		};
		stereo.system.dialog({
			"model" : "show",
			"timeout": "60000",
			"info" : "请稍候..."
		});
		stereo.file.upload(fileParam, uploadSuccess, fail);
	}
	
}

//上传图片成功
function uploadSuccess(data)
{
	//反馈类型
	var suggestionType = $("#suggestionType").val();
	//应用类型
	var appId = $("#appId").val();
	//内容
	var context = $("#context").val();
	var paramJson = {
		suggestionType: suggestionType,
		appId: appId,
		mediaID: data,
		context: encodeURI(context)
	};
	stereo.system.submitSuggestion(paramJson, submitSuggestionSuccess, fail);
}

//提交成功
function submitSuggestionSuccess(data)
{
	stereo.system.dialog({
		"model" : "close"
	});
	// 跳转到反馈问题列表页面
	window.location.href = "feedback.html";
}

//获取app信息成功
function getAppInfosSuccess(data)
{
	for (var i=0; i<data.length; i++)
	{
		if (i == 0)
		{
			$("#appId").append("<option selected='selected' value='" + data[i].appId + "' >" + data[i].appName + "</option>");
		}
		else
		{
			$("#appId").append("<option value='" + data[i].appId + "' >" + data[i].appName + "</option>");
		}
	}
	$("#appId").mobiscroll().select({
		theme: 'android-ics light',
		display: 'bottom',
		mode: 'scroller',
		lang:'zh',
		minWidth: 200,
		headerText: function (valueText) { return "应用"; } 
	});
}
		
//请求失败回调
function fail(data)
{
	alert(data);
}

/*时间控件样式*/
$(function () {
	
	$("#suggestionType").mobiscroll().select({
		theme: 'android-ics light',
		display: 'bottom',
		mode: 'scroller',
		lang:'zh',
		minWidth: 200,
		headerText: function (valueText) { return "反馈类型"; } 
	});
	
	$("#appId").mobiscroll().select({
		theme: 'android-ics light',
		display: 'bottom',
		mode: 'scroller',
		lang:'zh',
		minWidth: 200,
		headerText: function (valueText) { return "应用"; } 
	});
	
});

/**
 * 触发input获得焦点事件
 */
function triFocus(target)
{
	$(target).parent().find("input").focus();
}

//验证是否为空
function isNull(str)
{
	if (null == str || undefined == str || "" == str || "null" == str)
	{
		return true;
	}
	return false;
}