jQuery.smix.view = {

};