//供电单位编码
var orgNo = "";
//当前页码
var pageNo = 1;
//总页数
var totalPage = 1;
//每页记录数目
var pageSize = 15;
//查询条件
var searchParam = null;

$(document).ready(function() { 
	$("#tipDiv .tipItemDiv").click(function(){
		var conditionType = $(this).find("input").val();
		//跳转到搜索页面
		if ("00" == conditionType)
		{
			showDiv("searchDiv");
		}
		else
		{
			$("#conditionTypeName").html($(this).find("div:nth-child(3)").html());
			$("#conditionTypeIn").val(conditionType);
			$("#simpleConditionIn").val('');
		}
		$("#tipDiv").hide();
		$("#mask_select").hide();
	});
});

//跳转到搜索页面
function showSearchDiv()
{
	//重置搜索条件
	resetSearchCondition();
	//显示搜索页面
	showDiv("searchDiv");
}

//简单查询按钮响应事件
function searchClick()
{
	var simpleCondition = $("#simpleConditionIn").val();
	if (isNull(simpleCondition))
	{
		stereo.system.info({
			title: '提示',
			info:'请输入查询条件',
			timeout: '2000'
		});
		return;
	}
	pageNo = 1;
	totalPage = 0;
	var conditionType = $("#conditionTypeIn").val();
	if ("01" == conditionType)
	{
		searchParam = {
				consNo: "",
				consName: "",
				elecAddr: simpleCondition,
				barCode: "",
				mrSectNo: ""
		};
	}
	else if ("02" == conditionType)
	{
		searchParam = {
				consNo: simpleCondition,
				consName: "",
				elecAddr: "",
				barCode: "",
				mrSectNo: ""
		};
	}
	else
	{
		searchParam = {
				consNo: "",
				consName: simpleCondition,
				elecAddr: "",
				barCode: "",
				mrSectNo: ""
		};
	}
	//查询用户列表
	queryUserList(searchParam);
}

//高级查询按钮响应事件
function highSearchClick()
{
	var searchConsNo = $("#consNoIn").val();
	var consName = $("#consNameIn").val();
	var elecAddr = $("#addressIn").val();
	var barCode = $("#barCodeIn").val();
	var mrSectNo = $("#mrSectNoIn").val();
	if ("" == searchConsNo && "" == consName && "" == elecAddr
			&& "" == barCode && "" == mrSectNo)
	{
		stereo.system.info({
			title: '提示',
			info: '至少填写一个查询条件',
			timeout: '2000'
		});
	}
	else
	{
		pageNo = 1;
		totalPage = 0;
		searchParam = {
				consNo: searchConsNo,
				consName: consName,
				elecAddr: elecAddr,
				barCode: barCode,
				mrSectNo: mrSectNo
		};
		//查询用户列表
		queryUserList(searchParam);
	}	
}

//查询用户列表
function queryUserList(param)
{
	stereo.system.dialog({
		"model" : "show",
		"info" : "请稍候..."
	});
	$("#pullUp").show();
	// 查询用户列表参数
	var userListParam;
	if (null == param)
	{
		userListParam = {
				serviceId: "10001",
				consNo: "",
				consName: "",
				elecAddr: "",
				barCode: "",
				mrSectNo: "",
				orgNo: orgNo,
				pageNo: pageNo,
				pageSize: pageSize
		};
	}
	else
	{
		userListParam = {
				serviceId: "10001",
				consNo: param.consNo,
				consName: param.consName,
				elecAddr: param.elecAddr,
				barCode: param.barCode,
				mrSectNo: param.mrSectNo,
				orgNo: orgNo,
				pageNo: pageNo,
				pageSize: pageSize
		};
	}
	//查询用户列表
	stereo.ajax.post(userListParam, queryUserListSuccess, postFail);
}

//查询用户列表成功
function queryUserListSuccess(data)
{
	stereo.system.dialog({
		"model" : "close"
	});
	//返回成功
	if ("success" == data.ajax_flag)
	{
		var retData = data.ajax_data;
		//设置总页数
		totalPage = retData.totalPage;
		//当前页记录
		var userList = retData.results;
		if (1 == pageNo)
		{
			//清空用户列表
			$("#userListDiv").html('');
		}
		//如果已经是最后一页，隐藏上拉加载更多
		if (pageNo == retData.totalPage)
		{
			pullScroll.refresh();
	    	$("#pullUp").hide();
	    	hasLoadedAll=true;
		}
		//已展示的用户列表
		var userListDivContent = $("#userListDiv").html();
		//循环拼接用户列表
		for (var i=0; i<userList.length; i++)
		{
			userListDivContent += '<li><div class="userRowDiv">' +
										'<input type="hidden" value="' + userList[i].consNo + '"/>' +
										'<input type="hidden" value="' + userList[i].consName + '"/>' +
										'<input type="hidden" value="' + userList[i].contractCap + '"/>' +
										'<input type="hidden" value="' + userList[i].voltName + '"/>' +
										'<input type="hidden" value="' + userList[i].elecAddr + '"/>' +
										'<input type="hidden" value="' + userList[i].consSortCode + '"/>' +
										'<div style="width:20%;" class="div_img">';
			// TODO　01居民,02商户  后面根据接口修改
			if ("01" == userList[i].consSortCode)
			{
				userListDivContent += '<img class="img" style="width:64px;height:64px;" src="../../img/user.png">';
			}
			else
			{
				userListDivContent += '<img class="img" style="width:64px;height:64px;" src="../../img/shop.png">';
			}
			userListDivContent += '</div>' +
									'<div style="width:100%;height:100%;">' +
										'<div style="width:100%;height:50%;display:-webkit-box;-webkit-box-orient:horizontal;">' +
											'<div style="width:30%;line-height:45px;">' + userList[i].consNo + ' ' + userList[i].consName + '</div>' +
											'<div style="width:70%;line-height:45px;">合同容量：' + userList[i].contractCap + ' 电压等级：' + userList[i].voltName + '</div>' +
										'</div>' +
										'<div style="width:100%;height:50%;line-height:45px;">' + userList[i].elecAddr + '</div>' +
									'</div>' +
							  '</div><li>';
		}
		
	    $("#userListDiv").html(userListDivContent);
	    //刷新列表
	    pullScroll.refresh();
	    $("#userListDiv .userRowDiv").click(function(){
	    	var consNo = $(this).children().eq(0).val();
	    	//跳转至用户详细信息页面
			window.location.href = "../../html/dyyhkk/dyyhkkForm.html?consNo="+consNo;
	    });
		//显示用户列表页面
		showDiv("searchUserListDiv");
	}
	else
	{
		alert(data.ajax_msg);
	}
}

//显示\隐藏DIV
function showDiv(divId)
{
	if ("searchDiv" == divId)
	{
		var json = {
				onGoHistory:'hback',
				showLeftButton:'true',
				debug:'false'
			};
		stereo.web.config(json, null, null);
	}
	else
	{
		var json = {
				onGoHistory:'',
				showLeftButton:'true',
				debug:'false'
			};
		stereo.web.config(json, null, null);
	}
	
	$("#searchUserListDiv").hide();
	$("#searchDiv").hide();
	//锚点回到顶部
	document.getElementById('mainBody').scrollIntoView();
	$("#" + divId).show();
}

//重置搜索条件
function resetSearchCondition()
{
	$("#consNoIn").val("");
	$("#consNameIn").val("");
	$("#addressIn").val("");
	$("#barCodeIn").val("");
	$("#mrSectNoIn").val("");
}

//排序
function sortDg(type)
{
	var userArr = [];
	var rowArr = $("#userListDiv").find("li .userRowDiv");
	if (rowArr.length == 0) {
		return;
	}
	$.each(rowArr, function(key, node) {
		var consNo = $(node).children().eq(0).val();
		var consName = $(node).children().eq(1).val();
		var contractCap = $(node).children().eq(2).val();
		var voltName = $(node).children().eq(3).val();
		var elecAddr = $(node).children().eq(4).val();
		var consSortCode = $(node).children().eq(5).val();
		userArr.push({
			consNo: consNo, 
			consName: consName, 
			contractCap: contractCap,
			voltName: voltName,
			elecAddr: elecAddr,
			consSortCode: consSortCode
		});
	});
	if ('consName' == type)
	{
		var consNameImgSrc = $("#consNameImg").attr("src");
		if (consNameImgSrc.indexOf("asc") == -1)
		{
			$("#consNameImg").attr("src", "../../img/sort-alpha-asc.png");
			userArr.sort(nameDesc);
		}
		else
		{
			$("#consNameImg").attr("src", "../../img/sort-alpha-desc.png");
			userArr.sort(nameAsc);
		}
		
	}
	else if ('addr' == type)
	{
		$("#happenDateImg");
		var happenDateImgSrc = $("#happenDateImg").attr("src");
		if (happenDateImgSrc.indexOf("asc") == -1)
		{
			$("#happenDateImg").attr("src", "../../img/sort-alpha-asc.png");
			userArr.sort(addrDesc);
		}
		else
		{
			$("#happenDateImg").attr("src", "../../img/sort-alpha-desc.png");
			userArr.sort(addrAsc);
		}
	}
	else
	{
		return;
	}
	$("#userListDiv").empty();
	var content = '';
	for (var i=0; i<userArr.length; i++)
	{
		var user = userArr[i];
		content += '<li><div class="userRowDiv">' +
							'<input type="hidden" value="' + user.consNo + '"/>' +
							'<input type="hidden" value="' + user.consName + '"/>' +
							'<input type="hidden" value="' + user.contractCap + '"/>' +
							'<input type="hidden" value="' + user.voltName + '"/>' +
							'<input type="hidden" value="' + user.elecAddr + '"/>' +
							'<input type="hidden" value="' + user.consSortCode + '"/>' +
							'<div style="width:20%;" class="div_img">';
		// TODO　01居民,02商户  后面根据接口修改
		if ("01" == user.consSortCode)
		{
			content += '<img class="img" style="width:64px;height:64px;" src="../../img/user.png">';
		}
		else
		{
			content += '<img class="img" style="width:64px;height:64px;" src="../../img/shop.png">';
		}
		content += '</div>' +
								'<div style="width:100%;height:100%;">' +
									'<div style="width:100%;height:50%;display:-webkit-box;-webkit-box-orient:horizontal;">' +
										'<div style="width:30%;line-height:45px;">' + user.consNo + ' ' + user.consName + '</div>' +
										'<div style="width:70%;line-height:45px;">合同容量：' + user.contractCap + ' 电压等级：' + user.voltName + '</div>' +
									'</div>' +
									'<div style="width:100%;height:50%;line-height:45px;">' + user.elecAddr + '</div>' +
								'</div>' +
						  '</div><li>';
	}
	$("#userListDiv").html(content);
	//刷新列表
    pullScroll.refresh();
    $("#userListDiv .userRowDiv").click(function(){
    	var consNo = $(this).children().eq(0).val();
    	//跳转至用户详细信息页面
		window.location.href = "../../html/dyyhkk/dyyhkkForm.html?consNo="+consNo;
    });
}

function addrAsc(a, b){
	return a.elecAddr>b.elecAddr?1:-1;
}

function addrDesc(a, b){
	return a.elecAddr>b.elecAddr?-1:1;
}

function nameAsc(a, b){
	return a.consName>b.consName?1:-1;
}

function nameDesc(a, b){
	return a.consName>b.consName?-1:1;
}

var myScroll;
function loaded() {
	myScroll = new iScroll('wrapper', {
		snap: true,
		momentum: false,
		hScrollbar: false,
		onScrollEnd: function () {
			document.querySelector('#indicator > li.active').className = '';
			document.querySelector('#indicator > li:nth-child(' + (this.currPageX+1) + ')').className = 'active';
		}
	 });
}

//给input绑定监听事件
function bindInputEventListener()
{
	$(".input_input").bind("input propertychange", function() {
	    if (0 == $(this).val().length)
		{
			$(this).parent().find(".input_img").css("visibility", "hidden");
		}
		else
		{
			$(this).parent().find(".input_img").css("visibility", "visible");
		}
	});
	
	$(".input_input").bind("focusin", function() {
		if (0 != $(this).val().length)
		{
			$(this).parent().find(".input_img").css("visibility", "visible");
		}
	});
	
	$(".input_input").bind("focusout", function() {
	    var inputImg = $(this).parent().find(".input_img");
		setTimeout(function hideInputImg(){
			$(inputImg).css("visibility", "hidden");
		}, 150);
	});
	
	$(".input_img").bind("click", function() {
		$(this).parent().find(".input_input").val("");
		$(this).parent().find(".input_input").focus();
		$(inputImg).css("visibility", "hidden");
	});
}

//显示搜索条件类型选择tip
function showSearchType()
{
	$("#tipDiv").css("display", "-webkit-box");
	$("#mask_select").show();
}

var hasLoadedAll = false;
var pullScroll,
pullDownEl, pullDownOffset,
pullUpEl, pullUpOffset,
generatedCount = 0;

function pullDownAction() {
	pageNo=1;
	hasLoadedAll=false;
	queryUserList();  
}

function pullUpAction() {
	pageNo++;
	//查询更多绑定用户
	queryUserList();  
}

function loadedPull() {
	pullDownEl = document.getElementById('pullDown');
	pullDownOffset = pullDownEl.offsetHeight;
	pullUpEl = document.getElementById('pullUp');
	pullUpOffset = pullUpEl.offsetHeight;
	
	pullScroll = new iScroll('wrapper_pull', {
		scrollbarClass: 'myScrollbar',
		useTransition: true,
		topOffset: pullDownOffset,
		hScroll:false,
		onRefresh: function () {
			if (pullDownEl.className.match('loading')) {
				pullDownEl.className = '';
				pullDownEl.querySelector('.pullDownLabel').innerHTML = '松开刷新...';
			} else if (pullUpEl.className.match('loading')) {
				pullUpEl.className = '';
				pullUpEl.querySelector('.pullUpLabel').innerHTML = '上拉加载更多...';
			}
		},
		onScrollMove: function () {
			if (this.y > 5 && !pullDownEl.className.match('flip')) {
				pullDownEl.className = 'flip';
				pullDownEl.querySelector('.pullDownLabel').innerHTML = '松开即可刷新...';
				this.minScrollY = 0;
			} else if (this.y < 5 && pullDownEl.className.match('flip')) {
				pullDownEl.className = '';
				pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉刷新...';
				this.minScrollY = -pullDownOffset;
			} else if (this.y < (this.maxScrollY - 5) && !pullUpEl.className.match('flip') && !hasLoadedAll) {
				pullUpEl.className = 'flip';
				pullUpEl.querySelector('.pullUpLabel').innerHTML = '松开即可加载更多...';
				this.maxScrollY = this.maxScrollY;
			} else if (this.y > (this.maxScrollY + 5) && pullUpEl.className.match('flip') && !hasLoadedAll) {
				pullUpEl.className = '';
				pullUpEl.querySelector('.pullUpLabel').innerHTML = '上拉加载更多...';
				this.maxScrollY = pullUpOffset;
			}
		},
		onScrollEnd: function () {
			if (pullDownEl.className.match('flip')) {
				pullDownEl.className = 'loading';
				pullDownEl.querySelector('.pullDownLabel').innerHTML = '正在加载...';				
				pullDownAction();	// Execute custom function (ajax call?)
			} else if (pullUpEl.className.match('flip') && !hasLoadedAll) {
				pullUpEl.className = 'loading';
				pullUpEl.querySelector('.pullUpLabel').innerHTML = '正在加载...';				
				pullUpAction();	// Execute custom function (ajax call?)
			}
		}
	});
	
	setTimeout(function () { document.getElementById('wrapper_pull').style.left = '0'; }, 800);
}

document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);
document.addEventListener('DOMContentLoaded', loadedPull, false);

function hideTip(target)
{
	$("#tipDiv").hide();
	$(target).hide();
}

//验证是否为空
function isNull(str)
{
	if (null == str || undefined == str || "" == str)
	{
		return true;
	}
	return false;
}


//请求后台失败
function postFail(data)
{
	alert(data);
}

//返回事件处理函数
function hback()
{
	if ("block" == $("#searchDiv").css("display"))
	{
		var json = {
				onGoHistory:'',
				showLeftButton:'true',
				debug:'false'
			};
		stereo.web.config(json, null, null);
		showDiv("searchUserListDiv");
	}
}
