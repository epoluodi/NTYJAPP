//登录人信息
var loginInfo = null;
//用户信息
var consInfo = null;
//证件信息
var certList = null;
//联系人信息
var contactInfo = null;
//合同信息
var contractInfo = null;
//当前选择的照片
var currentImg;
//用电协议uuid
var uuid = null;
//用电协议标识
var contractId = null;
//用电协议编号
var contractNo = null;
//是否签署完用电协议
var isSign = false;

//初始化页面
function initUserDetail()
{
	var requestParam = getRequest();
	var consNo = requestParam.consNo;
	//重置参数
//	resetParam();
	var userDetailParam = {
			serviceId: "10002",
			consNo: consNo
	};
	stereo.system.dialog({
		"model" : "show",
		"info" : "请稍候..."
	});
	//查询用户详细信息
	stereo.ajax.post(userDetailParam, queryUserDetailSuccess, postFail);
}

//查询用户详细信息成功
function queryUserDetailSuccess(data)
{
	if ("success" == data.ajax_flag)
	{
		//用户信息
		consInfo = data.ajax_data.consMap;
		//合同信息
		contractInfo = {
				consName: consInfo.consName,
				elecAddr: consInfo.elecAddr,
				voltName: consInfo.voltName,
				operTypeCode: '01'
		};
		//联系人信息
		contactInfo = {
				contactId: consInfo.contactId,
				contactMode: consInfo.contactMode,
				contactName: consInfo.contactName,
				mobile: consInfo.mobile,
				homePhone: consInfo.homePhone,
				addr: consInfo.addr,
				consNo: consInfo.consNo
		};
		//电能表信息
		var meterList = data.ajax_data.meterList;
		if (!isNull(consInfo))
		{
			var userBasicListDivContent = '<div class="formRow">' +
												'<div class="formCol1_90" style="margin-left:10px;">' +
													'<div style="width:100%;text-align:left;line-height:50px;"><font style="color:red">*</font>用户名称</div>' +
												'</div>' +
											    '<div class="formCol2" style="margin-right: 10px;">' +
											    	'<div style="width:100%;">' +
											    		'<div class="input_div">' +
													    	'<input id="updateConsNameIn" type="text" style="text-align:right;" maxlength="20" class="input_input align_left" ' + 
											    			'value="' + consInfo.consName + '"/>' +
													    	'<img src="../../img/delete.png" class="input_img2">' +
													    '</div>' +
											    	'</div>' +
											    '</div>' +
											'</div>' +
											
											'<div class="formRow">' +
												'<div class="formCol1_90" style="margin-left:10px;">' +
													'<div style="width:100%;text-align:left;line-height:50px;"><font style="color:red">*</font>用电地址</div>' +
												'</div>' +
											    '<div class="formCol2" style="margin-right: 10px;">' +
											    	'<div style="width:100%;">' +
											    		'<div class="input_div">' +
													    	'<input id="updateAddrIn" type="text" style="text-align:right;" maxlength="20" class="input_input align_left" ' + 
													    	'value="' + consInfo.elecAddr + '"/>' +
													    	'<img src="../../img/delete.png" class="input_img2">' +
													    '</div>' +
											    	'</div>' +
											    '</div>' +
											'</div>' +
											
											'<div class="detailRowDiv">' +
												'<div>用户编号</div>' +
												'<div>' + consInfo.consNo + '</div>' +
											'</div>' +
											'<div class="detailRowDiv">' +
												'<div>供电单位名称</div>' +
												'<div>' + consInfo.orgName + '</div>' +
											'</div>' +
											'<div class="detailRowDiv">' +
												'<div>用电类型</div>' +
												'<div>' + consInfo.elecTypeName + '</div>' +
											'</div>' +
											'<div class="detailRowDiv">' +
												'<div>合同容量</div>' +
												'<div>' + consInfo.contractCap + '</div>' +
											'</div>' +
											'<div class="detailRowDiv">' +
												'<div>供电电压</div>' +
												'<div>' + consInfo.voltName + '</div>' +
											'</div>' +
											'<div class="detailRowDiv">' +
												'<div>缴费方式</div>' +
												'<div>' + consInfo.payModeName + '</div>' +
											'</div>';
			$("#userBasicListDiv").html(userBasicListDivContent);
		}
		
		var meterListDivContent = '';
		if (!isNull(meterList) && meterList.length != 0)
		{
			contractInfo.typeName = [meterList[0].typeName];
			if (1 == meterList.length)
			{
				meterListDivContent += '<div class="detailRowDiv">' +
												'<div>出厂编号</div>' +
												'<div>' + (isNull(meterList[0].madeNo) ? '':meterList[0].madeNo) + '</div>' +
										  '</div>' +
										  '<div class="detailRowDiv">' +
												'<div>类别名称</div>' +
												'<div>' + (isNull(meterList[0].sortName) ? '':meterList[0].sortName) + '</div>' +
										  '</div>' +
										  '<div class="detailRowDiv">' +
												'<div>电表类型</div>' +
												'<div>' + (isNull(meterList[0].typeName) ? '':meterList[0].typeName) + '</div>' +
										  '</div>' +
										  '<div class="detailRowDiv">' +
												'<div>型号</div>' +
												'<div>' + (isNull(meterList[0].modelName) ? '':meterList[0].modelName) + '</div>' +
										  '</div>';
			}
			else
			{
				var navContent = '<div id="nav" style="width:50px;position:relative;left:47%;padding-top:5px;">' +
									'<ul id="indicator">';
				meterListDivContent = '<div id="wrapper">' +
											'<div id="scroller">' +
												'<ul id="thelist">';
				for(var i=0; i<meterList.length; i++)
				{
					if ($.inArray(meterList[i].typeName, contractInfo.typeName))
					{
						contractInfo.typeName.push(meterList[i].typeName);
					}
					meterListDivContent += '<li>' +
												'<div class="detailRowDiv">' +
														'<div>出厂编号</div>' +
														'<div>' + (isNull(meterList[i].madeNo) ? '':meterList[i].madeNo) + '</div>' +
												  '</div>' +
												  '<div class="detailRowDiv">' +
														'<div>类别名称</div>' +
														'<div>' + (isNull(meterList[i].sortName) ? '':meterList[i].sortName) + '</div>' +
												  '</div>' +
												  '<div class="detailRowDiv">' +
														'<div>电表类型</div>' +
														'<div>' + (isNull(meterList[i].typeName) ? '':meterList[i].typeName) + '</div>' +
												  '</div>' +
												  '<div class="detailRowDiv">' +
														'<div>型号</div>' +
														'<div>' + (isNull(meterList[i].modelName) ? '':meterList[i].modelName) + '</div>' +
												  '</div>' +
											'</li>';
					if (0 == i)
					{
						navContent += '<li class="active"></li>';
					}
					else
					{
						navContent += '<li></li>';
					}
				}
				meterListDivContent += 	'</ul>' +
									'</div>' +
								'</div>';
				navContent += '</ul>' + '</div>';
				meterListDivContent += navContent;
			}
		}
		else
		{
			meterListDivContent += '<div class="detailRowDiv">' +
										'<div>出厂编号</div>' +
										'<div></div>' +
								  '</div>' +
								  '<div class="detailRowDiv">' +
										'<div>类别名称</div>' +
										'<div></div>' +
								  '</div>' +
								  '<div class="detailRowDiv">' +
										'<div>电表类型</div>' +
										'<div></div>' +
								  '</div>' +
								  '<div class="detailRowDiv">' +
										'<div>型号</div>' +
										'<div></div>' +
								  '</div>';
		}
		$("#meterListDiv").html(meterListDivContent);
		//显示用户详细页面
		showDiv("userDetailDiv");
		if (null != meterList && meterList.length > 1)
		{
			//添加滑动监听事件
			loaded();
			$("#detailTip").css({"margin-top":$("#wrapper").height() + 15});
		}	
		if (!isNull(consInfo))
		{
			//初始化input监听事件
			bindInputEventListener();
			$("#updateConsNameIn").bind("focusin", function() {
				$("#updateConsNameIn").css("text-align","left");
			});
			$("#updateConsNameIn").bind("focusout", function() {
				$("#updateConsNameIn").css("text-align","right");
			});
			$("#updateAddrIn").bind("focusin", function() {
				$("#updateAddrIn").css("text-align","left");
			});
			$("#updateAddrIn").bind("focusout", function() {
				$("#updateAddrIn").css("text-align","right");
			});
		}
	}
	else
	{
		alert(data.ajax_msg);
	}
	stereo.system.dialog({
		"model" : "close"
	});
}

//跳转到用户证件信息列表页面
function jumpToVertList()
{
	//校验用户详细信息
	if (!checkUserDetail())
	{
		return;
	}
	//更新用户档案
	var userProfileParam = {
			serviceId: "10003",
			consNo: consInfo.consNo,
			consName: $("#updateConsNameIn").val(),
			elecAddr: $("#updateAddrIn").val()
	};
	stereo.system.dialog({
		"model" : "show",
		"info" : "请稍候..."
	});
	//更新用户档案
	stereo.ajax.post(userProfileParam, updateUserProfileSuccess, postFail);
}

//更新用户档案成功
function updateUserProfileSuccess(data)
{
	consInfo.consName = $("#updateConsNameIn").val();
	consInfo.elecAddr = $("#updateAddrIn").val();
	
	if ("success" == data.ajax_flag)
	{
		var certParam = {
				serviceId: "10004",
				consNo: consInfo.consNo
		};
		//查询证件信息列表
		stereo.ajax.post(certParam, queryCertListSuccess, postFail);
	}
	else
	{
		alert(data.ajax_msg);
	}
}

//查询证件列表信息成功
function queryCertListSuccess(data)
{
	if ("success" == data.ajax_flag)
	{
		certList = data.ajax_data.certLists.certList;
		//证件列表为空,直接跳转至证件新增页面
		if (null == certList)
		{
			jumpToAddCert(null);
		}
		else
		{
			var userCertListContent = '';
			if (certList instanceof Array)
			{
				for (var i=0; i<certList.length; i++)
				{
					var certInfo = certList[i];
					userCertListContent += '<div class="div1">' +
												'<div class="div2">';
					if ("01" == certInfo.certType)
					{
						userCertListContent += '<div><img src="../../img/idcard.png"><label>' + certInfo.certName + '</label></div>';
					}
					//默认是身份证
					else
					{
						userCertListContent += '<div><img src="../../img/idcard.png"><label>' + certInfo.certName + '</label></div>';
					}	
					userCertListContent += 	'<div>' + certInfo.certNo + '</div>' +
										'</div>' +
								    '</div>';
				}
			}
			else
			{
				userCertListContent += '<div class="div1">' +
											'<div class="div2">';
				if ("01" == certList.certType)
				{
					userCertListContent += '<div><img src="../../img/idcard.png"><label>' + certList.certName + '</label></div>';
				}
				//默认是身份证
				else
				{
					userCertListContent += '<div><img src="../../img/idcard.png"><label>' + certList.certName + '</label></div>';
				}	
				userCertListContent += 	'<div>' + certList.certNo + '</div>' +
									'</div>' +
							    '</div>';
			}
			
			$("#certListDiv").html(userCertListContent);
			$("#certListDiv .div1").click(function(){
				var certNo = $(this).find(".div2 div:nth-child(2)").html();
				jumpToAddCert(certNo);
			});
			showDiv("userCertListDiv");
		}
	}
	else
	{
		alert(data.ajax_msg);
	}
	stereo.system.dialog({
		"model" : "close"
	});
}

//跳转到添加证件信息页面
function jumpToAddCert(certNo)
{
	//重置用户证件详细信息
	if (null == certNo)
	{
		resetCertDetail();
		showDiv("userCertDetailDiv");
	}
	//修改证件
	else
	{
		//遍历certList,初始化证件信息页面数据
		if (null != certList)
		{
			stereo.system.dialog({
				"model" : "show",
				"timeout": '30000',
				"info" : "请稍候..."
			});
			if (certList instanceof Array)
			{
				for (var i=0; i<certList.length; i++)
				{
					var certInfo = certList[i];
					if (certNo == certInfo.certNo)
					{
						for (var j=0; j<$("#certType option").length; j++)
						{
							if (certInfo.certType == $("#certType option").eq(j).val())
							{
								$("#certType option").eq(j).selected = true;
								break;
							}
						}
						$("#certIdIn").val(certInfo.certId);
						$("#certNameIn").val(certInfo.certName);
						$("#certNoIn").val(certInfo.certNo);
						$("#certEffectDateIn").val(certInfo.certEffectDate);
						$("#certExpireDateIn").val(certInfo.certExpireDate);
						
						var dirRectoryArr = certInfo.dirRectory.split(",");
						//下载证件照
						stereo.file.download({
							mediaID:dirRectoryArr
						}, downloadSuccess, postFail);
						break;
					}
				}
			}
			else
			{
				if (certNo == certList.certNo)
				{
					for (var j=0; j<$("#certType option").length; j++)
					{
						if (certList.certType == $("#certType option").eq(j).val())
						{
							$("#certType option").eq(j).selected = true;
							break;
						}
					}
					$("#certIdIn").val(certList.certId);
					$("#certNameIn").val(certList.certName);
					$("#certNoIn").val(certList.certNo);
					$("#certEffectDateIn").val(certList.certEffectDate);
					$("#certExpireDateIn").val(certList.certExpireDate);
					
					var dirRectoryArr = certList.dirRectory.split(",");
					//下载证件照
					stereo.file.download({
						mediaID:dirRectoryArr
					}, downloadSuccess, postFail);
				}
			}
			
		}
	}
}

//证件照下载成功
function downloadSuccess(data)
{
	var datas = data.split(",");
	$("#faceImg").attr("src", datas[0]);
	$("#reversedImg").attr("src", datas[1]);
	$("#faceImg").css("width", $(document).width()/2-10-5 + "px");
	$("#faceImg").css("height", $("#faceImg").parent().height() + "px");
	$("#reversedImg").css("width", $(document).width()/2-10-5 + "px");
	$("#reversedImg").css("height", $("#reversedImg").parent().height() + "px");
	showDiv("userCertDetailDiv");
	stereo.system.dialog({
		"model" : "close"
	});
}

//添加或修改证件信息
function addCert()
{
	//校验证件信息
	if (!checkVert())
	{
		return;
	}
	
	var certId = $("#certIdIn").val();
	if (isNull(certId))
	{
		var certNo = $("#certNoIn").val();
		//判断添加\修改的证件是否在证件列表中
		if (null != certList)
		{
			for (var i=0; i<certList.length; i++)
			{
				if (certNo == certList[i].certNo)
				{
					stereo.system.info({
						title: '提示',
						info:'证件号码不能重复录入',
						timeout: '2000'
					});
					return false;
				}
			}
		}
	}
	//更新证件
	updateCert();
}

//更新证件信息
function updateCert()
{
	//上传证件照片
	var faceImgSrc = $("#faceImg").attr("src");
	var reversedImgSrc = $("#reversedImg").attr("src");
	var fileParam = {
			fileType: "JPG",
			files: [faceImgSrc, reversedImgSrc]
	};
	stereo.system.dialog({
		"model" : "show",
		"timeout": '30000',
		"info" : "请稍候..."
	});
	stereo.file.upload(fileParam, uploadCertSuccess, postFail);
}

//上传图片成功回调
function uploadCertSuccess(data)
{
	//用户证件信息
	var certId = $("#certIdIn").val();
	var certType = $("#certType").val();
	var certTypeName = $("#certType")[0].options[$("#certType")[0].selectedIndex].text;
	var certName = $("#certNameIn").val();
	var certNo = $("#certNoIn").val();
	var certEffectDate = $("#certEffectDateIn").val();
	var certExpireDate = $("#certExpireDateIn").val();
	var certParam = {
			serviceId: "10005",
			consNo: consInfo.consNo,
			certId: isNull(certId) ? null : certId,
			certType: certType,
			certTypeName: encodeURI(certTypeName),
			certName: encodeURI(certName),
			certNo: certNo,
			certEffectDate: certEffectDate,
			certExpireDate: certExpireDate,
			dirRectory: data
	};
	//更新证件信息
	stereo.ajax.post(certParam, updateCertSuccess, postFail);
}

//更新证件信息成功
function updateCertSuccess(data)
{
	//返回成功
	if ("success" == data.ajax_flag)
	{
		var certParam = {
				serviceId: "10004",
				consNo: consInfo.consNo
		};
		//查询证件信息列表
		stereo.ajax.post(certParam, queryCertListSuccess, postFail);
	}
	else
	{
		alert(data.ajax_msg);
	}
}

//跳转到核实用户联系信息页面
function jumpToContact()
{
	//用户联系信息不为空
	if (null != contactInfo)
	{
		$("#contactIdIn").val(contactInfo.contactId);
		$("#contactModeIn").val(contactInfo.contactMode);
		$("#contactNameIn").val(contactInfo.contactName);
		$("#mobileIn").val(contactInfo.mobile);
		$("#homePhoneIn").val(contactInfo.homePhone);
		$("#addrIn").val(contactInfo.addr);
	}
	else
	{
		//重置用户联系信息
		resetContact();
	}	
	
	showDiv("userContactDiv");
}

//跳转到用电协议页面
function jumpToContract()
{
	//检查联系人、证件信息是否符合约束条件
	if (!checkContact())
	{
		return false;
	}
	//修改联系人信息
	updateContact();
}

//更新联系人信息
function updateContact()
{
	//联系人信息
	var contactId = $("#contactIdIn").val();
	var contactMode = $("#contactModeIn").val();
	var contactName = $("#contactNameIn").val();
	var mobile = $("#mobileIn").val();
	var homePhone = $("#homePhoneIn").val();
	var addr = $("#addrIn").val();
	var contactParam = {
			serviceId: "10006",
			consNo: consInfo.consNo,
			contactId: isNull(contactId) ? null : contactId,
			contactMode: isNull(contactMode) ? "02" : contactMode,
			contactName: contactName,
			mobile: mobile,
			homePhone: homePhone,
			addr: addr
	};
	stereo.system.dialog({
		"model" : "show",
		"info" : "请稍候..."
	});
	//更新联系人信息
	stereo.ajax.post(contactParam, updateContactSuccess, postFail);
}

//更新联系人信息
function updateContactSuccess(data)
{
	//返回成功
	if ("success" == data.ajax_flag)
	{
		var contactData = data.ajax_data;
		//更新联系人数据
		contactInfo = {
				contactId: contactData.contactId,
				contactMode: "02",
				contactName: contactData.contactName,
				mobile: contactData.mobile,
				homePhone: contactData.homePhone,
				addr: contactData.addr,
				consNo: contactData.consNo
		};
		
		//重置用电协议页面
		resetBargin();
		//初始化用电协议页面数据
		var contractInfoContent = '<div class="blockDiv">' +
									'<div class="titleDiv">甲方</div>' +
									'<div style="padding-top:5px;">' +
										'<div class="detailRowDiv">' +
											'<div>供电人</div>' +
											'<div>天府供电公司</div>' +
									    '</div>' +
									    '<div class="detailRowDiv">' +
											'<div>供电方式</div>' +
											'<div>交流低压' + contractInfo.voltName + '</div>' +
									    '</div>' +
									'</div>' +
								'</div>' +
								'<div class="blockDiv">' +
						    		'<div class="titleDiv">乙方</div>' +
							    	'<div style="padding-top:5px;">' +
							    		'<div class="detailRowDiv">' +
											'<div>用电人</div>' +
											'<div>' + contractInfo.consName + '</div>' +
									    '</div>' +
									    '<div class="detailRowDiv">' +
											'<div>用电地址</div>' +
											'<div>' + contractInfo.elecAddr + '</div>' +
									    '</div>' +
									    '<div class="detailRowDiv">' +
											'<div>计量装置</div>' +
											'<div>' + contractInfo.typeName + '</div>' +
									    '</div>' +
							    	'</div>' +
							    '</div>';
		$("#contractInfoDiv").html(contractInfoContent);
		//显示用电协议页面
		showDiv("contractDiv");
	}
	else
	{
		alert(data.ajax_msg);
	}
	stereo.system.dialog({
		"model" : "close"
	});
}

//创建用电协议
function makeContract()
{
	var queryContractParam = {
			serviceId: "10008",
			consNo: consInfo.consNo
	};
	stereo.system.dialog({
		"model" : "show",
		"info" : "请稍候..."
	});
	//查询该客户是否已签署过用电协议
	stereo.ajax.post(queryContractParam, queryContractListSuccess, postFail);
}

//查询用电协议成功
function queryContractListSuccess(data)
{
	//返回成功
	if ("success" == data.ajax_flag)
	{
		var contractList = data.ajax_data.contractLists.contractList;
		if (isNull(contractList) || contractList.length == 0)
		{
			var generateContractNoParam = {
					serviceId: "10007"
			};
			//生成用电协议编号
			stereo.ajax.post(generateContractNoParam, generateContractNoSuccess, postFail);
		}
		else
		{
			//提示是否变更用电协议
			if (confirm("该用户已签署用电协议，是否变更？"))
			{
				//变更用电协议
				contractInfo.operTypeCode = '02';
				var data = {
	        			ajax_flag: "success",
	        			ajax_data: {
	        				contractId: contractList.contractId,
	        				contractNo: contractList.contractNo
	        			}
	        	};
	        	generateContractNoSuccess(data);
			}
			else
			{
				stereo.system.dialog({
					"model" : "close"
				});
			}
		}
	}
	else
	{
		alert(data.ajax_msg);
	}
}

//生成用电协议编号成功
function generateContractNoSuccess(data)
{
	//返回成功
	if ("success" == data.ajax_flag)
	{
		//用电协议标识
		contractId = data.ajax_data.contractId;
		//用电协议编号
		contractNo = data.ajax_data.contractNo;
		
		//TODO 将标识、编号放入合同中
		stereo.file.create({
		        templatePath : "template/bargain.docx",  //用电协议文件的目录
		        fileType: "WORD", //文件类型 为 WORD
		        "placeholder" : {
	        	"param1" : consInfo.consName,
	        	"param2" : loginInfo.orgName,
		        "param3" : contractInfo.elecAddr,
		        "param4" : '5'
	        }
		}, makeSuccess, makeFail);
	}
	else
	{
		alert(data.ajax_msg);
	}
}

//用电协议创建成功
function makeSuccess(json)
{
	stereo.system.dialog({
		"model" : "close"
	});
	uuid = json.file;
	
	//隐藏生成用电协议按钮，显示预览、签字按钮
	$("#makeContractDiv").hide();
	$("#previewContractDiv").css("display", "-webkit-box");
}

//用电协议创建失败
function makeFail(data)
{
	alert('用电协议创建失败');
}

//预览用电协议
function previewContract()
{
	stereo.file.preview({file:uuid}, null, null);
}

//签字
function sign()
{
	//用电协议已生成并且用电协议已签署
	if (isSign && null != uuid)
	{
		alert("用电协议已签署");
		return;
	}
	stereo.file.edit({
			file:uuid,   // 文件ID
			xOffSet:330,  // x偏移量
			yOffSet:190,
			fileType:'WORD'
		}, // y 偏移量
		signSuccess, signFail);
}

//签字失败
function signFail(data)
{
	alert(data);
}

//签字成功
function signSuccess(data)
{
	//展示签署页图片
	$("#contractSignImg").attr("src", data.image);
	showDiv("signPageDiv");
	var param = {
			serviceId: "10010"
	};
	//查询服务器当前时间
	stereo.ajax.post(param, queryCurrentTimeSuccess, postFail);
}

//查询当前日期成功
function queryCurrentTimeSuccess(data)
{
	contractInfo.signDate = data.ajax_data.today;
	contractInfo.consSignDate = data.ajax_data.today;
}

//确认签署页
function confirmSign()
{
	//上传合同文件
	var fileParam = {
			fileType: "WORD",
			files: [uuid]
	};
	stereo.system.dialog({
		"model" : "show",
		"info" : "请稍候..."
	});
	stereo.file.upload(fileParam, uploadContractSuccess, postFail);
}

//合同文件上传成功
function uploadContractSuccess(data)
{
	var contractParam = {
			serviceId: "10009",
			consNo: consInfo.consNo, 
			contractId: "",
			contractNo: contractNo,
			sortCode: "01",
			typeCode: "03",
			signDate: contractInfo.signDate,
			endDate: "",
			signAddr: consInfo.elecAddr,
			psSignatory: loginInfo.name,
			consSignatory: consInfo.consName,
			consSignDate: contractInfo.consSignDate,
			stateCode: "2",
			operTypeCode: contractInfo.operTypeCode,
			mediaId: data,
			appNo: ""
	};
	//上传用电协议
	stereo.ajax.post(contractParam, updateContractSuccess, postFail);
}

//更新用电协议成功
function updateContractSuccess(data)
{
	//返回成功
	if ("success" == data.ajax_flag)
	{
		isSign = true;
		showDiv("signSuccessDiv");
	}
	else
	{
		alert(data.ajax_msg);
	}
	stereo.system.dialog({
		"model" : "close"
	});
}

//校验用户详细信息
function checkUserDetail()
{
	if (isNull($("#updateConsNameIn").val()))
	{
		stereo.system.info({
			title: '提示',
			info:'请填写"用户名称"',
			timeout: '2000'
		});
		return false;
	}
	if (isNull($("#updateAddrIn").val()))
	{
		stereo.system.info({
			title: '提示',
			info:'请填写"用电地址"',
			timeout: '2000'
		});
		return false;
	}
	return true;
}

//校验证件信息
function checkVert()
{
	if ("0" == $("#certType").val())
	{
		stereo.system.info({
			title: '提示',
			info:'请选择"证件类型"',
			timeout: '2000'
		});
		return false;
	}
	if (isNull($("#certNameIn").val()))
	{
		stereo.system.info({
			title: '提示',
			info:'请填写"证件名称"',
			timeout: '2000'
		});
		return false;
	}
	if (isNull($("#certNoIn").val()))
	{
		stereo.system.info({
			title: '提示',
			info:'请填写"证件号码"',
			timeout: '2000'
		});
		return false;
	}
	if ("01" == $("#certType").val() && !isCardNo($("#certNoIn").val()))
	{
		stereo.system.info({
			title: '提示',
			info:'请填写正确的"证件号码"',
			timeout: '2000'
		});
		return false;
	}
	if (isNull($("#certEffectDateIn").val()))
	{
		stereo.system.info({
			title: '提示',
			info:'请选择"生效日期"',
			timeout: '2000'
		});
		return false;
	}
	if (isNull($("#certExpireDateIn").val()))
	{
		stereo.system.info({
			title: '提示',
			info:'请选择"失效日期"',
			timeout: '2000'
		});
		return false;
	}
	if (-1 != $("#faceImg").attr("src").indexOf("cert_face_default.png"))
	{
		stereo.system.info({
			title: '提示',
			info:'请添加"证件正面照"',
			timeout: '2000'
		});
		return false;
	}
	if (-1 != $("#reversedImg").attr("src").indexOf("cert_reversed_default.png"))
	{
		stereo.system.info({
			title: '提示',
			info:'请添加"证件反面照"',
			timeout: '2000'
		});
		return false;
	}
	return true;
}

//校验联系人信息
function checkContact()
{
	if (isNull($("#contactNameIn").val()))
	{
		stereo.system.info({
			title: '提示',
			info:'请填写"联系人"',
			timeout: '2000'
		});
		return false;
	}
	if (isNull($("#mobileIn").val()))
	{
		stereo.system.info({
			title: '提示',
			info:'请填写"移动电话"',
			timeout: '2000'
		});
		return false;
	}
	if (!isMobileNo($("#mobileIn").val()))
	{
		stereo.system.info({
			title: '提示',
			info:'请填写正确的"移动电话"',
			timeout: '2000'
		});
		return false;
	}
	if (!isNull($("#homePhoneIn").val()) && !isHomePhone($("#homePhoneIn").val()))
	{
		stereo.system.info({
			title: '提示',
			info:'请填写正确的"住宅电话"',
			timeout: '2000'
		});
		return false;
	}
	return true;
}

//选择图片
function showImageDiv(target)
{
	currentImg = target;
	var currentImgSrc = $(currentImg).attr("src");
	
	var paramJson = {
			chooseModel: "all",
			imageCount : "2"
		};
	//调用app原生应用，弹出pop菜单，让用户选择拍照，还是从相册获取
	stereo.camera.chooseImage(paramJson, cameraSuccess, cameraFail);

	
	//如果是默认图片，则选择图片
/*	if (-1 != currentImgSrc.indexOf("cert_default.png"))
	{
		var paramJson = {
			chooseModel: "all",
			imageCount : "2"
		};
		//调用app原生应用，弹出pop菜单，让用户选择拍照，还是从相册获取
		stereo.camera.chooseImage(paramJson, cameraSuccess, cameraFail);
	}
	//预览已选图片
	else
	{
		var imgSrcs = [];
		$.each($(".certImgDiv img"),function(index,item){
			if (-1 == $(item).attr("src").indexOf("cert_default.png"))
			{
				imgSrcs.push($(item).attr("src"));
			}
	    });
		var paramJson = {
				images: imgSrcs,
				viewModel: "slider",
				src: currentImgSrc
			};
		//预览图片
		stereo.camera.imagePreview(paramJson);
	}
*/	
}

//图片选择成功回调
function cameraSuccess(data){
	var contacthtml = "";
	if(data.photos == 0)
	{
		stereo.system.info({
			title: '提示',
			info: '请选择图片',
			timeout: '2000'
		});
		return;
	}
	if (1 == data.photofile.length)
	{
		var imgAddr = data.photofile[0];
		$(currentImg).attr("src", imgAddr);
		$(currentImg).css("width", $(currentImg).parent().parent().width()-5 + "px");
		$(currentImg).css("height", $(currentImg).parent().height() + "px");
	}
	else if (2 == data.photofile.length)
	{
		var imgAddr1 = data.photofile[0];
		var imgAddr2 = data.photofile[1];
		$("#faceImg").attr("src", imgAddr1);
		$("#reversedImg").attr("src", imgAddr2);
		
		$("#faceImg").css("width", $(document).width()/2-10-5 + "px");
		$("#faceImg").css("height", $("#faceImg").parent().height() + "px");
		$("#reversedImg").css("width", $(document).width()/2-10-5 + "px");
		$("#reversedImg").css("height", $("#reversedImg").parent().height() + "px");
	}	
}

//图片选择失败回调
function cameraFail(data)
{
	alert('选择图片失败');
}

//证件类型变更
function certTypeChange()
{
	var selectedCertType = $("#certType").val();
	var selectedCertTypeName = $("#certType")[0].options[$("#certType")[0].selectedIndex].text;
}

//证件生效日期变更
function selectEffectDate()
{
	//生效日期
	var certEffectDateStr = $("#certEffectDateIn").val();
    var certEffectDate = new Date(certEffectDateStr.replace(/-/g,"/"));
	//失效日期
	var certExpireDateStr = $("#certExpireDateIn").val();
    var certExpireDate = new Date(certExpireDateStr.replace(/-/g,"/"));
    if ((Date.getAddDaysDate(certEffectDate, 1).getTime()) > (Date.getAddDaysDate(certExpireDate, 1).getTime()))
    {
    	stereo.system.info({
			title: '提示',
			info:'生效日期不能早于失效日期',
			timeout: '2000'
		});
    	$("#certEffectDateIn").val('');
        return;
    }
}

//证件失效日期变更
function selectExpireDate()
{
	//生效日期
	var certEffectDateStr = $("#certEffectDateIn").val();
    var certEffectDate = new Date(certEffectDateStr.replace(/-/g,"/"));
	//失效日期
	var certExpireDateStr = $("#certExpireDateIn").val();
    var certExpireDate = new Date(certExpireDateStr.replace(/-/g,"/"));
    if ((Date.getAddDaysDate(certEffectDate, 1).getTime()) > (Date.getAddDaysDate(certExpireDate, 1).getTime()))
    {
    	stereo.system.info({
			title: '提示',
			info:'失效日期不能晚于生效日期',
			timeout: '2000'
		});
    	$("#certExpireDateIn").val('');
        return;
    }
}

//显示\隐藏DIV
function showDiv(divId)
{
	//刷新进度条
	refreshProcess(divId);
	if ("userDetailDiv" == divId)
	{
		var json = {
				onGoHistory: '',
				showLeftButton:'false',
				debug:'false'
			};
		stereo.web.config(json, null, null);
	}
	else
	{
		var json = {
				onGoHistory:'hback',
				showLeftButton:'false',
				debug:'false'
			};
		stereo.web.config(json, null, null);
	}
	$("#userDetailDiv").hide();
	$("#userCertListDiv").hide();
	$("#userCertDetailDiv").hide();
	$("#userContactDiv").hide();
	$("#contractDiv").hide();
	$("#signPageDiv").hide();
	$("#signSuccessDiv").hide();
	//锚点回到顶部
	document.getElementById('mainBody').scrollIntoView();
	$("#" + divId).show();
}

//重置搜索条件
function resetSearchCondition()
{
	$("#consNoIn").val("");
	$("#consNameIn").val("");
	$("#addressIn").val("");
	$("#barCodeIn").val("");
	$("#mrSectNoIn").val("");
}

//重置参数
function resetParam()
{
	uuid = null;
	isSign = false;
}

//重置用户证件详细信息
function resetCertDetail()
{
	$("#certType option[value='01']").attr("selected",true);
	$("#certNameIn").val("");
	$("#certNoIn").val("");
	$("#certEffectDateIn").val("");
	$("#certExpireDateIn").val("");
	$("#faceImg").attr("src", "../../img/cert_face_default.png");
	$("#reversedImg").attr("src", "../../img/cert_reversed_default.png");
	$("#faceImg").css("width", "120px");
	$("#faceImg").css("height", "120px");
	$("#reversedImg").css("width", "120px");
	$("#reversedImg").css("height", "120px");
}

//重置用户联系信息
function resetContact()
{
	$("#contactNameIn").val("");
	$("#mobileIn").val("");
	$("#homePhoneIn").val("");
	$("#addrIn").val("");
}

//重置用电协议页面
function resetBargin()
{
	$("#makeContractDiv").show();
	$("#previewContractDiv").hide();
}

//注销用电协议编号成功
function destoryContractNoSuccess()
{
	//删除用电协议物理文件，释放资源
	stereo.file.release({file:uuid}, null, null);
	uuid = null;
	showDiv("userContactDiv");
}

//刷新进度条
function refreshProcess(divId)
{
	var proWidth = $(".singleProcess div").eq(0).width();
	var proX = $(".singleProcess div").eq(0).offset().left;
	//核实用户档案
	if ("userDetailDiv" == divId)
	{
		$("#userDetailProDiv").css({"background-color":"#F9CF49"});
		$("#certProDiv").css("background-color", "#EEEEEE");
		$(".processGreenLine").css("width", "0px");
	}
	//核实用户证件
	else if ("userCertListDiv" == divId || "userCertDetailDiv" == divId)
	{
		$("#userDetailProDiv").css({"background-color":"#38B69A"});
		$("#certProDiv").css("background-color", "#F9CF49");
		$("#contactProDiv").css("background-color", "#EEEEEE");
		$(".processGreenLine").css("width", ($(document).width()-2*proX-proWidth)/3+"px");
	}
	//核实联系人
	else if ("userContactDiv" == divId)
	{
		$("#certProDiv").css("background-color", "#38B69A");
		$("#contactProDiv").css("background-color", "#F9CF49");
		$("#contractProDiv").css("background-color", "#EEEEEE");
		$(".processGreenLine").css("width", ($(document).width()-2*proX-proWidth)/3*2+"px");
	}
	//合同签署完毕
	else if ("signSuccessDiv" == divId)
	{
		$("#contractProDiv").css("background-color", "#38B69A");
		$(".processGreenLine").css("width", ($(document).width()-2*proX-proWidth)+"px");
	}
	//签署合同
	else
	{
		$("#contactProDiv").css("background-color", "#38B69A");
		$("#contractProDiv").css("background-color", "#F9CF49");
		$(".processGreenLine").css("width", ($(document).width()-2*proX-proWidth)+"px");
	}
}

//验证是否为空
function isNull(str)
{
	if (null == str || undefined == str || "" == str || "null" == str)
	{
		return true;
	}
	return false;
}
//验证身份证格式
function isCardNo(card)
{
	// 身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X  
    var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
	return reg.test(card);
} 
//验证手机号码
function isMobileNo(no)
{
	var reg = /^1\d{10}$/;
	var reg1 = /^\d{3,4}-{0,1}\d{6,8}$/;
	if (reg.test(no))
		return true;
	if (reg1.test(no))
		return true;
	return false;
//	var reg = /^1[3|4|5|8][0-9]\d{4,8}$/;
//	if (reg.test(no))
//		return true;
//	return false;
}

//验证固话
function isHomePhone(no)
{
	var reg = /^(\d{3,4}\-?)?\d{7,8}$/;
	if (reg.test(no))
		return true;
	return false;
}

/**
 * 触发input获得焦点事件
 */
function triFocus(target)
{
	$(target).parent().find("input").focus();
}

//请求后台失败
function postFail(data)
{
	alert(data);
}

//返回事件处理函数
function hback()
{
	if ("block" == $("#userDetailDiv").css("display"))
	{
		//调用平台的返回方法
		stereo.system.goback();
	}
	else if ("block" == $("#userCertListDiv").css("display"))
	{
		showDiv("userDetailDiv");
	}
	else if ("block" == $("#userCertDetailDiv").css("display"))
	{
		//证件列表为空,返回跳到用户详细信息页面
		if (null == certList || 0 == certList.length)
		{
			showDiv("userDetailDiv");
		}
		//跳到证件列表页面
		else
		{
			showDiv("userCertListDiv");
		}
	}
	else if ("block" == $("#userContactDiv").css("display"))
	{
		showDiv("userCertListDiv");
	}
	else if ("block" == $("#contractDiv").css("display"))
	{
		//用电协议已生成并且用电协议未签署
		if (!isSign && null != uuid)
		{
			//TODO 提示是否放弃当前已生成的合同
			if (confirm("放弃当前已生成的合同？"))
			{
				var destoryContractNoParam = {
	        			serviceId: "10007",
	        			contractId: contractId,
	        			optType: "02",
	        			contractNo: contractNo
	        	};
	        	//注销合同编号
	        	stereo.ajax.post(destoryContractNoParam, destoryContractNoSuccess, postFail);
			}
		}
		else
		{
			showDiv("userContactDiv");
		}	
	}
	else if ("block" == $("#signPageDiv").css("display"))
	{
		showDiv("contractDiv");
	}
	else if ("block" == $("#signSuccessDiv").css("display"))
	{
		var json = {
				onGoHistory:'',
				showLeftButton:'false',
				debug:'false'
			};
		stereo.web.config(json, null, null);
		//调用平台的返回方法
		stereo.system.goback();
	}
}

function getRequest() 
{ 
	var url = location.search; //获取url中"?"符后的字串
	var theRequest = new Object();
	if (url.indexOf("?") != -1)
	{
		var str = url.substr(1);
		strs = str.split("&");
		for(var i = 0; i < strs.length; i ++)
		{
			theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
		}
	}
	return theRequest;
} 