jQuery.smix.view = {

};